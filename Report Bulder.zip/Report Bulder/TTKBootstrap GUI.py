import tkinter as tk
from tkinter import *
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from GUI_DFs import *
import docx
from datetime import *
import os


def style_changed(event):
    colour = styles.get()
    s = ttk.Style()
    if colour == "Superhero":
        s.theme_use("superhero")
    elif colour == "Darkly":
        s.theme_use("darkly")
    elif colour == "Sandstone":
        s.theme_use("sandstone")
    elif colour == "Solar":
        s.theme_use("solar")
    elif colour == "Cyborg":
        s.theme_use("cyborg")
    elif colour == "Vapor":
        s.theme_use("vapor")
    elif colour == "Cosmo":
        s.theme_use("cosmo")
    elif colour == "Morph":
        s.theme_use("morph")
    elif colour == "Journal":
        s.theme_use("journal")
    elif colour == "Litera":
        s.theme_use("litera")


def df_window():
    # Window and Frames. Made 3 variables global so that they can be used
    global dfs, dfs2, searchbar, my_listbox
    df_window = tk.Toplevel(root)
    df_window.title("Deficiencies")
    df_window.geometry("400x500")
    df_frame = ttk.Frame(df_window)
    df_frame.place(relx=0.5, rely=0.1, relwidth=0.75, relheight=0.8, anchor=N)

    # Title
    title = ttk.Label(df_window, text="Deficiencies", font=("Inter", 12, "bold"))
    title.pack(pady=10)

    # Search box
    search_lable = ttk.Label(df_frame, text="Search Deficiencies:", font=("Arial", 9))
    search_lable.place(relx=0, rely=0)
    searchbar = ttk.Entry(df_frame, font=("Inter", 10))
    searchbar.bind("<KeyRelease>", check)
    searchbar.place(relx=0, rely=0.05, relwidth=1)

    # List of all Dfs
    dfs = {"Two Factor Authentication": twofactorauth,
           }
    # list of DFs needing a modification
    dfs2 = {"Shared Office Space": (shared_office_space, shared_office_space_mod),
            "Device Encryption": (device_encryption, device_encryption_mod)}


    # list box
    my_listbox = tk.Listbox(df_frame, selectmode=SINGLE)
    my_listbox.place(relx=0, rely=0.13, relwidth=1, relheight=0.7)
    my_listbox.bind("<<ListboxSelect>>", lambda event: fill_out(event))
    # Add Button
    add_df_b = ttk.Button(df_frame, text="Add", width=15, bootstyle="OUTLINE-SUCCESS", command=move_data, state=NORMAL)
    add_df_b.pack(side=BOTTOM)
    update_data(dfs, dfs2)



def update_data(data1, data2):
    my_listbox.delete(0, END)
    for item in data1:
        my_listbox.insert(END, item)
    for item in data2:
        my_listbox.insert(END, item)


def fill_out(event):
    # Delete content in entry box
    searchbar.delete(0, END)
    # Add clicked list item to entry box
    searchbar.insert(0, my_listbox.get(ACTIVE))


def check(event):
    # grab what was typed
    typed = searchbar.get()
    if typed == "":
        data1 = dfs
        data2 = dfs2
    else:
        data1 = []
        data2 = []
        for item in dfs:
            if typed.lower() in item.lower():
                data1.append(item)
        for item in dfs2:
            if typed.lower() in item.lower():
                data2.append(item)
    # update our listbox with selected items
    update_data(data1, data2)


def move_data():
    selection = searchbar.get()
    if selection in dfs2:
        df_listbox.insert(0, f"{selection}***")
    else:
        df_listbox.insert(0, selection)


def delete_item():
    selected = df_listbox.curselection()
    if selected:
        df_listbox.delete(selected[0])


def close_app():
    close_window = tk.Toplevel(root)
    close_window.title("Close App")
    confirm = ttk.Label(close_window, font=("Inter", 12), text="""
    Are you sure you want to close the app?      
    All info will be lost.       
    """)
    confirm.pack(pady=20, padx=20, side=TOP)
    end_button = ttk.Button(close_window, text="End Session", width=15, command=destroy, bootstyle=DANGER)
    end_button.pack(pady=20)


def finish_app():
    global finish_window
    finish_window = tk.Toplevel(root)
    finish_window.title("Close App")
    confirm = ttk.Label(finish_window, font=("Inter", 12), text="""
    Are you sure you would like to finish your report?      
    Now is your chance to fix any mistakes.       
    """)
    confirm.pack(pady=20, padx=20, side=TOP)
    done_button = ttk.Button(finish_window, text="Done", width=15, command=finish, bootstyle=PRIMARY)
    done_button.pack(pady=20)


def destroy():
    root.quit()


def finish():
    # Fetch the values in the DF listbox and execute the corresponding instructions
    values = df_listbox.get(0, END)
    for value in values:
        action = dfs.get(value)
        actions2 = dfs2.get(value)
        if action:
            action(root, doc2)
        if actions2:
            actions2[0](root, doc2)
    # Start Building the Compliance Report
    # date
    today = date.today()
    formatted_today = today.strftime("%B %d, %Y")
    doc.add_paragraph(f"{formatted_today}\n", style='No Spacing')
    # name
    first_name, last_name = entry1.get().split(" ")
    full_name = f"{first_name} {last_name}"
    doc.add_paragraph(full_name, style="No Spacing")
    doc.add_paragraph("Investia Financial Services", style="No Spacing")
    # Trade Name
    while True:
        if entry3.get() == "":
            break
        else:
            doc.add_paragraph(entry3.get(), style="No Spacing")
            break
    # Address
    address = entry2.get()
    len(address)
    last_six = address[-6:]
    doc.add_paragraph(address[:-6], style='No Spacing')
    doc.add_paragraph(f"{last_six.upper()}", style='No Spacing')

    # Review Date
    review_date = date_entry.entry.get()
    specific_date = date(*map(int, review_date.split("-")))
    formatted_review_date = specific_date.strftime("%B %d, %Y")
    due_date = date.today() + timedelta(days=30)
    formatted_due_date = due_date.strftime("%B %d, %Y")

    # Intro
    doc.add_paragraph(f"""
RE: Branch Review Report

Dear {first_name},

Further to our Branch Review conducted on {formatted_review_date}, please review the findings below requiring your immediate attention. Please note that this report is not intended to comment on approved Outside Activities (“OA”), and therefor any non-findings should not be construed to mean that such activities comply with the applicable rules and/or requirements associated with that OA.

Your response is required by {formatted_due_date}, describing the steps taken or that you intend to take with respect to each of the deficiencies outlined. For your convenience, the report includes an Appendix to assist you in documenting the response and any applicable action plan for each of the deficiencies outlined within. All issues identified do not necessarily need to be resolved by the response date; however, we do expect that all matters be resolved within 30 days of the report being issued to allow us to close your review.""",style='No Spacing')

    cbm = entry4.get()
    doc.add_paragraph(""" 
If you require further clarification or additional information, please feel free to contact me directly. Thank you again for your time and cooperation.

Sincerely,""", style='No Spacing')
    from docx.shared import Inches
    # adding my signature
    doc.add_picture('Signature.PNG', width=Inches(2))
    doc.add_paragraph(f'Austin Brocca, Branch Auditor \ncc:\t{cbm}, Corporate Branch Manager')

    doc.save(f"Compliance Report - {full_name}.docx")
    doc2.save(f"Advisor Appendix - {full_name}.docx")

    destroy()
    print("Done!")


def modify_df():
    value = df_listbox.curselection()
    if len(value) > 0:
        index = value[0]
        item = df_listbox.get(index)
        if "***" in item:
            item = item.replace("***", "")
            df_listbox.delete(index)
            df_listbox.insert(index, item)
            dfs2[df_listbox.get(value)][1](root)

# Main Window --------------------------------------------------------------------------------
root = ttk.Window(themename="solar", title="Audit Assist")
root.geometry("500x900")

# Create docs
doc = docx.Document("Template.docx")
doc2 = docx.Document("AdvisorAppendix.docx")
# title
title = ttk.Label(root, text="Audit Assist", font=("Inter", 15, "bold"))
title.pack(pady=20)

# Frame 1 with close and finish buttons ----------------------------------------------------
frame1 = ttk.Frame(root)
frame1.place(relx=0.5, rely=0.1, relwidth=0.90, relheight=0.05, anchor=N)
c_button = ttk.Button(frame1, text='Close', bootstyle="DANGER-OUTLINE", width=15, command=close_app)
c_button.pack(side=LEFT, padx=50)
f_button = ttk.Button(frame1, text="Finish", bootstyle=PRIMARY, width=15, command=finish_app)
f_button.pack(side=RIGHT, padx=50)

# Frame 2 with Advisor info -------------------------------------------------------------------
frame2 = ttk.LabelFrame(root, padding=10, text="Advisor Info")
frame2.place(relx=0.5, rely=0.18, relwidth=0.90, relheight=0.18, anchor=N)

rep_name = ttk.Label(frame2, text="Full Name:", font=("Arial", 9))
rep_name.place(relx=0.02, rely=0.05)
entry1 = ttk.Entry(frame2)
entry1.place(relx=0.02, rely=0.20, relwidth=0.46)

address = ttk.Label(frame2, text="Address:", font=("Arial", 9))
address.place(relx=0.02, rely=0.5)
entry2 = ttk.Entry(frame2)
entry2.place(relx=0.02, rely=0.65, relwidth=0.46)

trade_name = ttk.Label(frame2, text="Trade Name: (Leave empty if N/A)", font=("Arial", 9))
trade_name.place(relx=0.52, rely=0.05)
entry3 = ttk.Entry(frame2)
entry3.place(relx=0.52, rely=0.20, relwidth=0.46)

cbm = ttk.Label(frame2, text="CBM Name:", font=("Arial", 9))
cbm.place(relx=0.52, rely=0.5)
entry4 = ttk.Entry(frame2)
entry4.place(relx=0.52, rely=0.65, relwidth=0.46)

# Frame 3 with Audit Info ----------------------------------------------------------------------
frame3 = ttk.LabelFrame(root, padding=10, text="Audit Info")
frame3.place(relx=0.5, rely=0.4, relwidth=0.90, relheight=0.12, anchor=N)

files_reviewed = ttk.Label(frame3, text="Number of files reviewed:", font=("Arial", 9))
files_reviewed.place(relx=0.02, rely=0.05)
entry5 = ttk.Entry(frame3)
entry5.place(relx=0.02, rely=0.3, relwidth=0.46)
review_date = ttk.Label(frame3, text="Review Date:", font=("Arial", 9))
review_date.place(relx=0.52, rely=0.05)
date_entry = ttk.DateEntry(frame3)
date_entry.place(relx=0.52, rely=0.3, relwidth=0.46)

# Frame 4 with deficiencies ---------------------------------------------------------------------
frame4 = ttk.LabelFrame(root, padding=10, text="Deficiencies")
frame4.place(relx=0.5, rely=0.57, relwidth=0.90, relheight=0.25, anchor=N)
added_dfs = ttk.Label(frame4, text="""Added Deficiencies: 
Items with *** require modification""", font=('Arial', 9))
added_dfs.place(relx=0.02, rely=0)
df_listbox = tk.Listbox(frame4)
df_listbox.place(relx=0.02, rely=0.19, relwidth=0.6, relheight=0.7)

add_button = ttk.Button(frame4, text="Add", bootstyle="SUCCESS-OUTLINE", width=15, command=df_window)
add_button.place(relx=0.71, rely=0.19)
remove_button = ttk.Button(frame4, text="Modify", bootstyle="INFO-OUTLINE", width=15, command=modify_df)
remove_button.place(relx=0.71, rely=0.42)
modify_button = ttk.Button(frame4, text="Remove", bootstyle="DANGER-OUTLINE", width=15, command=delete_item)
modify_button.place(relx=0.71, rely=0.65)

# Frame 5 with appearance mode and zoom ----------------------------------------------------------
frame5 = ttk.LabelFrame(root, text="App Appearance")
frame5.place(relx=0.5, rely=0.95, relwidth=0.90, relheight=0.10, anchor=S)

# Styles Combobox + Variables
styles_label = ttk.Label(frame5, text="Appearance:", font=("Arial", 9))
styles_label.place(relx=0.04, rely=0.09)
selected_style = tk.StringVar()
styles = ttk.Combobox(frame5, width=10, state="readonly", bootstyle=INFO, textvariable=selected_style)
styles['values'] = ('Darkly', 'Superhero', "Solar", "Cyborg", "Vapor", 'Sandstone', "Cosmo", "Morph", "Journal",
                    "Litera")
styles.bind('<<ComboboxSelected>>', style_changed)
styles.current(2)
styles.place(relx=0.04, rely=0.4)

# Zoom Combobox + Variables
zoom_label = ttk.Label(frame5, text="Zoom:", font=("Arial", 9))
zoom_label.place(relx=0.76, rely=0.09)
selected_zoom = tk.StringVar
zoom = ttk.Combobox(frame5, width=10, state="readonly", bootstyle=INFO, textvariable=selected_zoom)
zoom['values'] = ('100%', '120%')
zoom.current(0)
zoom.place(relx=0.76, rely=0.4)

KYC_Updates_Mod(root, entry5)
# launch app -------------------------------------------------------------------------------------------
mainloop()
