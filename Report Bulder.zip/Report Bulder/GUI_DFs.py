import tkinter as tk
from tkinter import *
import ttkbootstrap as ttk
from docx.shared import Pt


# Two Factor Authentication ----------------------------------------------
def twofactorauth(root, doc2):
    print("Two Factor Authentication")
    table = doc2.tables[0]
    new_row = table.add_row()
    new_row.cells[0].text = "Two Factor Authentication (2FA or MFA)"
    new_row.cells[1].text = "Please confirm that you have enabled 2FA to secure your email address."
    for run in new_row.cells[0].paragraphs[0].runs:
        run.bold = True
        run.font.name = 'Calibri (Body)'
        run.font.size = Pt(10)
    for run in new_row.cells[1].paragraphs[0].runs:
        run.font.name = 'Calibri (Body)'
        run.font.size = Pt(10)
    new_para = new_row.cells[0].add_paragraph(f"""During the review, you confirmed that you have not yet enabled two-factor authentication (2FA or MFA) to secure your email address.

To avoid breaches of privacy arising from a lost or stolen device or intercepted communication, your personal devices containing client information must always be encrypted and the emails that you send must be secured.

We refer you to the Cybersecurity Guidelines released March 2020 states:
Email services are used for business purposes and to facilitate communications between representatives and their clients. You must keep in mind that:""")
    new_para.runs[0].font.name = 'Calibri (Body)'
    new_para.runs[0].font.size = Pt(10)
    new_row.cells[0].add_paragraph("Email is not secure natively and is easily intercepted.", style='List Bullet')
    new_row.cells[0].add_paragraph("Email should be used for general correspondence.", style='List Bullet')
    new_row.cells[0].add_paragraph("Use secure email for all communications containing sensitive information",
                                   style='List Bullet')
    new_para = new_row.cells[0].add_paragraph("Why should you protect confidential information sent by email?")
    new_para.runs[0].font.name = 'Calibri (Body)'
    new_para.runs[0].font.size = Pt(10)
    new_row.cells[0].add_paragraph("An email with private information can be sent to the wrong recipient.",
                                   style='List Bullet')
    new_row.cells[0].add_paragraph("An unauthorized person could access your email account", style='List Bullet')
    new_para = new_row.cells[0].add_paragraph(
        "The use of two-factor authentication (2FA or MFA) is an additional tool to secure your email address ensuring you are the person accessing your email.")
    new_para.runs[0].font.name = 'Calibri (Body)'
    new_para.runs[0].font.size = Pt(10)
    new_row.cells[0].add_paragraph("Turn on two-factor authentication to secure your email access", style='List Bullet')
    new_row.cells[0].add_paragraph(
        "There are many different tools you can use for email protection which are discussed further in Cybersecurity Guidelines. Best services for 2FA are:  Google Authenticator, Microsoft Authenticator, LastPass, Authy",
        style='List Bullet')
    new_para = new_row.cells[0].add_paragraph(
        "We refer you to the Cybersecurity Guidelines released March 2020 which has been provided to you along with this report. In addition, we recommend that you contact your IT professional regularly to ensure your devices and email are secure.\n")
    new_para.runs[0].font.name = 'Calibri (Body)'
    new_para.runs[0].font.size = Pt(10)


# Shared Office Space ----------------------------------------------------
def shared_office_space(root, doc2):
    print("Shared Office Space")
    table = doc2.tables[0]
    new_row = table.add_row()
    new_row.cells[0].text = "Shared Office Space"
    new_row.cells[1].text = "Please outline what steps will be taken to address the noted deficiency(ies), and an approximate timeline for completion."
    for run in new_row.cells[0].paragraphs[0].runs:
        run.bold = True
        run.font.name = 'Calibri (Body)'
        run.font.size = Pt(10)
    for run in new_row.cells[1].paragraphs[0].runs:
        run.font.name = 'Calibri (Body)'
        run.font.size = Pt(10)

    if len(q2_answers) == 2:
        new_para = new_row.cells[0].add_paragraph(
            f"We noted that you currently share office space with {q_answers[1]}, but you do not {', '.join(q2_answers[:-1])}. Additionally, you do not {q2_answers[-1]}.\n")
        new_para.runs[0].font.name = 'Calibri (Body)'
        new_para.runs[0].font.size = Pt(10)

    elif len(q2_answers) > 2:
        new_para = new_row.cells[0].add_paragraph(
            f"We noted that you currently share office space with {q_answers[1]}, but you do not {', '.join(q2_answers[:-1])} and {q2_answers[-1]}.\n")
        new_para.runs[0].font.name = 'Calibri (Body)'
        new_para.runs[0].font.size = Pt(10)
    else:
        new_para = new_row.cells[0].add_paragraph(f"We noted that you currently share office space with {q_answers[1]}, but you do not {q2_answers[0]}.\n")
        new_para.runs[0].font.name = 'Calibri (Body)'
        new_para.runs[0].font.size = Pt(10)

    new_para = new_row.cells[0].add_paragraph("""Chapter 3, Section I of the CPPM dated June 2022, states:
The practice of Representatives sharing office space with other businesses, professionals and/or mutual fund representatives from other dealers is generally acceptable under the following conditions: """)
    new_para.runs[0].font.name = 'Calibri (Body)'
    new_para.runs[0].font.size = Pt(10)
    new_row.cells[0].add_paragraph("Separate and distinct signage must be visible;", style='List Bullet')
    new_row.cells[0].add_paragraph("Separate telephone and fax lines must be maintained;", style='List Bullet')
    new_row.cells[0].add_paragraph("Services of an assistant must not be shared", style='List Bullet')
    new_row.cells[0].add_paragraph("Client files must be secure and access restricted from the other business or entity;", style='List Bullet')
    new_row.cells[0].add_paragraph("Office doors must be locked in the Representative’s absence; and", style='List Bullet')
    new_row.cells[0].add_paragraph("Additional privacy restrictions must be adhered to.", style='List Bullet')
    new_para = new_row.cells[0].add_paragraph("""The greatest risk of sharing office space is the protection and adherence to client privacy rights. When a client gives their consent to the sharing and use of certain information at the time of account opening, this DOES NOT include the sharing of information with individuals or businesses with whom the Representative shares office space. Therefore, special care must be taken to ensure there is no sharing of client contact records or other information with anyone other than Investia personnel.
    
Special regard must be given to such day-to-day matters:""")
    new_para.runs[0].font.name = 'Calibri (Body)'
    new_para.runs[0].font.size = Pt(10)
    new_row.cells[0].add_paragraph("Closing and storing client files securely when not in use;", style='List Bullet')
    new_row.cells[0].add_paragraph("Ensuring faxing practices are confidential and secure; and", style='List Bullet')
    new_row.cells[0].add_paragraph("Ensuring telephone conversations with clients regarding confidential matters are private and discreet.\n", style='List Bullet')
    new_para = new_row.cells[0].add_paragraph("""If the office space is shared with another financial entity, the potential for client confusion must be addressed. It must be clear which products and services are provided through and supervised by Investia. It is the responsibility of the Representative to ensure that the client understands that there is more than one financial entity in the same office space and that they are separate businesses.  

NOTE: It is not sufficient to have a non-employee sign a confidentiality disclosure; all of the above requirements must be met. 
""")
    new_para.runs[0].font.name = 'Calibri (Body)'
    new_para.runs[0].font.size = Pt(10)


def shared_office_space_mod(root):
    # lists
    global q_answers, q2_answers
    q_answers = []
    q2_answers = []
    cons = ["keep separate, distinct, and visible signage", "maintain separate telephone and fax lines",
            "ensure services of an assistant are not shared",
            "secure client files and keep access restricted from the other business entity",
            "keep office doors locked in your absence", "adhere to additional privacy restrictions"]
    mod_window = tk.Toplevel(root)
    mod_window.title("Shared Office Space Modifications")
    mod_window.geometry("500x400")
    # First Question
    q_label = ttk.Label(mod_window, font=("Inter", 11), text="Name of the business they share space with:")
    q_label.place(relx=0.1, rely=0.1)
    q_entry = ttk.Entry(mod_window)
    q_entry.place(relx=0.1, rely=0.16, relwidth=0.8)
    q_answers.append(q_entry.get())
    # Second Question
    q_label2 = ttk.Label(mod_window, font=("Inter", 11), text="Select which conditions were not met:")
    q_label2.place(relx=0.1, rely=0.30)
    conditions = tk.Listbox(mod_window, selectmode="multiple")
    for item in cons:
        conditions.insert(END, item)
    conditions.place(relx=0.1, rely=0.36, relwidth=0.8)
    # Button
    ok = ttk.Button(mod_window, text="OK", width=15, command=lambda: [q_answers.append(q_entry.get()), q2_answers.extend([cons[i] for i in conditions.curselection()]), print(q_answers), print(q2_answers), mod_window.destroy()])
    ok.pack(side=BOTTOM, pady=20)


# Device Encryption ------------------------------------------------------
def device_encryption(root, doc2):
    table = doc2.tables[0]
    new_row = table.add_row()
    new_row.cells[0].text = "Device Encryption"
    new_row.cells[
        1].text = "Please confirm on the attached response document that your electronic devices are encrypted."
    for run in new_row.cells[0].paragraphs[0].runs:
        run.bold = True
        run.font.name = 'Calibri (Body)'
        run.font.size = Pt(10)
    for run in new_row.cells[1].paragraphs[0].runs:
        run.font.name = 'Calibri (Body)'
        run.font.size = Pt(10)
    new_para = new_row.cells[0].add_paragraph(f"""We noted that your {de_list[0]} is/are not encrypted.

    Chapter 3, Section I of the CPPM Dated June 2022, states:
    Avoid Breaches of Privacy
    Personal information collected during the conduct of business activities must not be used or disclosed for purposes other than those for which it was obtained, unless the consent of the person is obtained, or as otherwise required by law. There are several ways the Representative may avoid breaches of privacy including:\n""")
    new_para.runs[0].font.name = 'Calibri (Body)'
    new_para.runs[0].font.size = Pt(10)
    bullet_para = new_row.cells[0].add_paragraph()
    bullet_para.add_run(
        "Appropriate device encryption must be enabled on and all devices (i.e. computer, mobile phone and any other electronic device) which include client information\n")
    bullet_para.style = 'List Bullet'
    print("Device Encryption")


def device_encryption_mod(root):
    # list
    global de_list
    de_list = []
    mod_window = tk.Toplevel(root)
    mod_window.title("Device Encryption Modifications")
    mod_window.geometry("400x400")
    q_label = ttk.Label(mod_window, font=("Inter", 11), text="""Which devices were not encrypted? 
Example: "laptop and smartphone" """)
    q_label.place(relx=0.1, rely=0.1)
    q_entry = ttk.Entry(mod_window)
    q_entry.place(relx=0.1, rely=0.20, relwidth=0.8)
    ok = ttk.Button(mod_window, text="OK", width=15, command=lambda: [de_list.append(q_entry.get()), print(de_list), mod_window.destroy()])
    ok.pack(side=BOTTOM, pady=20)


# KYC Updates ------------------------------------------------------------
def KYC_Updattes(root, doc2):
    table = doc2.tables[0]
    new_row = table.add_row()
    new_row.cells[0].text = "KYC Updates"
    new_row.cells[1].text = "Please confirm your understanding of this policy and provide your comments and or action plan in the space provided below.\n"
    for run in new_row.cells[0].paragraphs[0].runs:
        run.bold = True
        run.font.name = 'Calibri (Body)'
        run.font.size = Pt(10)
    for run in new_row.cells[1].paragraphs[0].runs:
        run.font.name = 'Calibri (Body)'
        run.font.size = Pt(10)



def KYC_Updates_Mod(root, entry5):
    mod_window = tk.Toplevel(root)
    mod_window.title("KYC Updates Modifications")
    mod_window.geometry("500x500")

    q_label = ttk.Label(mod_window, font=("Inter", 9), text="Did you find any expired KYCs in your trade review?")
    q_label.place(relx=0.1, rely=0.05)

    def sel():
        if rb_var.get() == 1:
            q2()
        else:
            try:
                q2_label.destroy()
                q2_entry.destroy()
            except:
                pass

    rb_var = IntVar()
    yes = ttk.Radiobutton(mod_window, text="Yes", variable=rb_var, value=1, command=sel)
    yes.place(relx=0.1, rely=0.1)
    no = ttk.Radiobutton(mod_window, text="No", variable=rb_var, value=2, command=sel)
    no.place(relx=0.25, rely=0.1)

    def q2():
        global q2_label
        global q2_entry
        q2_label = ttk.Label(mod_window, font=("Inter", 9), text=f"Of the {entry5.get()} files you reviewed, how many files were expired? (Example: 2):")
        q2_label.place(relx=0.1, rely=0.15)
        q2_entry = ttk.Entry(mod_window)
        q2_entry.place(relx=0.1, rely=0.20, relwidth=0.8)

    q3_label = ttk.Label(mod_window, font=("Inter", 9), text="Was more than 10% of the rep's book expired?")
    q3_label.place(relx=0.1, rely=0.28)

    def sel2():
        if rb_var2.get() == 1:
            q4()
        else:
            for widget in (q4_label, total_clients, total_clients_label, exp_KYCs_label,
                           exp_KYCs, missing_KYCs_label, missing_KYCs, calculate_button):
                try:
                    widget.destroy()
                except:
                    pass

    rb_var2 = IntVar()
    yes2 = ttk.Radiobutton(mod_window, text="Yes", variable=rb_var2, value=1, command=sel2)
    yes2.place(relx=0.1, rely=0.33)
    no1 = ttk.Radiobutton(mod_window, text="No", variable=rb_var2, value=2, command=sel2)
    no1.place(relx=0.25, rely=0.33)


    def q4():
        global q4_label, total_clients, total_clients_label, exp_KYCs_label, exp_KYCs, missing_KYCs_label, \
            missing_KYCs, percentage_exp, calculate_button, repeat_label, yes3, no3
        q4_label = ttk.Label(mod_window, font=("Inter", 9),
                             text="Enter book information:")
        q4_label.place(relx=0.1, rely=0.40)
        total_clients_label = ttk.Label(mod_window, font=("Inter", 9), text="Number of Clients:")
        total_clients_label.place(relx=0.1, rely=0.45)

        total_clients = ttk.Entry(mod_window)
        total_clients.place(relx=0.1, rely=0.5, relwidth=0.21)

        exp_KYCs_label = ttk.Label(mod_window, font=("Inter", 9), text="Expired KYCs:")
        exp_KYCs_label.place(relx=0.39, rely=0.45)

        exp_KYCs = ttk.Entry(mod_window)
        exp_KYCs.place(relx=0.39, rely=0.5, relwidth=0.21)

        missing_KYCs_label = ttk.Label(mod_window, font=("Inter", 9), text="Missing KYCs:")
        missing_KYCs_label.place(relx=0.69, rely=0.45)

        missing_KYCs = ttk.Entry(mod_window)
        missing_KYCs.place(relx=0.69, rely=0.5, relwidth=0.21)

        def calculate():
            try:
                total = int(total_clients.get())
                exp = int(exp_KYCs.get() or 0)
                missing = int(missing_KYCs.get() or 0)

            except ValueError:
                print("Error: Invalid Input")
                return

            percentage_exp = round(((exp + missing) / total) * 100, 1)
            print(percentage_exp)
            cal_label = ttk.Label(mod_window, font=("Inter", 9), text=f"{percentage_exp}%")
            cal_label.place(relx=0.20, rely=0.60)

            if percentage_exp > 40:
                repeat_label = ttk.Label(mod_window, font=("Inter", 9), text="Was this a repeat deficiency?:")
                repeat_label.place(relx=0.1, rely=0.7)

                rb_var3 = IntVar()
                yes3 = ttk.Radiobutton(mod_window, text="Yes", variable=rb_var3, value=1)
                yes3.place(relx=0.1, rely=0.75)
                no3 = ttk.Radiobutton(mod_window, text="No", variable=rb_var3, value=2)
                no3.place(relx=0.25, rely=0.75)

        calculate_button = ttk.Button(mod_window, text="Calculate", command=calculate, bootstyle="OUTLINE-INFO")
        calculate_button.place(relx=0.1, rely=0.62, anchor="center")

    submit_button = ttk.Button(mod_window, text="Submit")
    submit_button.place(relx=0.5, rely=0.9, anchor="center")

















